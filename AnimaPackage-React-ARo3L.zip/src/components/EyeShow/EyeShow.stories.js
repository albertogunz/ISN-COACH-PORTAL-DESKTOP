import { EyeShow } from ".";

export default {
  title: "Components/EyeShow",
  component: EyeShow,
};

export const Default = {
  args: {
    className: {},
    eyeShow: "/img/eye-show.svg",
  },
};
