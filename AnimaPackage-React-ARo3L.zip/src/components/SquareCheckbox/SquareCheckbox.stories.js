import { SquareCheckbox } from ".";

export default {
  title: "Components/SquareCheckbox",
  component: SquareCheckbox,
};

export const Default = {
  args: {
    className: {},
    squareCheckbox: "/img/square-checkbox-solid.svg",
  },
};
