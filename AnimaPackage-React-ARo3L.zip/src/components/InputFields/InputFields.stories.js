import { InputFields } from ".";

export default {
  title: "Components/InputFields",
  component: InputFields,
  argTypes: {
    property1: {
      options: ["default", "variant-5", "variant-2", "variant-3", "variant-4", "variant-8", "variant-7", "variant-6"],
      control: { type: "select" },
    },
  },
};

export const Default = {
  args: {
    property1: "default",
    className: {},
    overlapGroupClassName: {},
    errorMessageClassName: {},
    text: "Name",
    boxClassName: {},
    keyFieldClassName: {},
    startCursorClassName: {},
    maskLayerClassName: {},
    maskLayer: "/img/mask-layer-7.png",
    endCursorClassName: {},
    endCursor: "/img/end-cursor-7.png",
  },
};
