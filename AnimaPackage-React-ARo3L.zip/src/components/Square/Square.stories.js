import { Square } from ".";

export default {
  title: "Components/Square",
  component: Square,
};

export const Default = {
  args: {
    className: {},
    square: "/img/square.svg",
  },
};
